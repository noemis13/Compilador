#include <stdio.h>
void printf_f(float f) {
	printf("%f\n",f);
}

float scanf_f() {
	float num;
	scanf("%f", &num);
	return num;	
}

