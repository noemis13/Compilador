# Trabalho de Compiladores

1) Análise léxica
2) Análise Semântica
3) Análise Sintática
4) Geração de código
